<?php

/**
 * Prevent direct access to the script.
 */
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Woo_Multisite_Stock_Sync_Ui {

    private $sites;

    public function __construct() {
        $this->sites = Woo_Multisite_Stock_Sync_Utils::sites();

        // Registrar admin menu
        add_action( 'admin_menu', array( $this, 'admin_menu' ), 20 );

        // ajax
        add_action( 'wp_ajax_wmss_disable_sync', array( $this, 'ajax_disable_sync' ) );
    }

    /**
     * Agregar pagina en submenu de WooCommerce
     */
    public function admin_menu() {
        add_submenu_page(
            'woocommerce',
            __( 'Multisite Stock Sync', 'woo-multisite-stock-sync' ),
            __( 'Multisite Stock Sync', 'woo-multisite-stock-sync' ),
            'manage_woocommerce',
            'woo-multisite-stock-sync-report',
            array( $this, 'output' )
        );
    }

    public function output() {
        $action = isset( $_GET['action'] ) ? $_GET['action'] : '';

        switch ( $action ) {
            case 'update':
                return $this->update_page();
            case 'push_all':
                return $this->push_all_page();
            case 'tools':
                return $this->tools_page();
            case 'log':
                // return $this->log();
        }

        return $this->report_page();
    }

    /**
     * URLs to common tasks
     */
    private static function urls() {
        return array(
            'update'   => add_query_arg(
                array(
                    'page'   => 'woo-multisite-stock-sync-report',
                    'action' => 'update',
                ),
                admin_url( 'admin.php' )
            ),
            'push_all' => add_query_arg(
                array(
                    'page'   => 'woo-multisite-stock-sync-report',
                    'action' => 'push_all',
                ),
                admin_url( 'admin.php' )
            ),
            'report'   => add_query_arg(
                array(
                    'page'   => 'woo-multisite-stock-sync-report',
                    'action' => '',
                ),
                admin_url( 'admin.php' )
            ),
        );
    }

    private static function tabs() {
        $action = isset( $_GET['action'] ) ? $_GET['action'] : '';

        $tabs = array();

        $tabs['report'] = array(
            'title'  => __( 'Productos', 'woo-multisite-stock-sync' ),
            'url'    => add_query_arg(
                array(
                    'page'   => 'woo-multisite-stock-sync-report',
                    'action' => '',
                ),
                admin_url( 'admin.php' )
            ),
            'active' => empty( $action ),
        );

        $tabs['tools'] = array(
            'title'  => __( 'Herramientas', 'woo-multisite-stock-sync' ),
            'url'    => add_query_arg(
                array(
                    'page'   => 'woo-multisite-stock-sync-report',
                    'action' => 'tools',
                ),
                admin_url( 'admin.php' )
            ),
            'active' => ( $action === 'tools' ),
        );

        $tabs['settings'] = array(
            'title'  => __( 'Ajustes', 'woo-multisite-stock-sync' ),
            'url'    => admin_url( 'admin.php?page=wc-settings&tab=woo_multisite_stock_sync' ),
            'active' => false,
        );

        return $tabs;
    }

    public function update_page() {
        $tabs                    = self::tabs();
        $urls                    = self::urls();
        $tabs['tools']['active'] = true;

        include __DIR__ . '/views/update.html.php';
    }

    public function push_all_page() {
        $tabs                    = self::tabs();
        $urls                    = self::urls();
        $tabs['tools']['active'] = true;

        include __DIR__ . '/views/push-all.html.php';
    }

    public function report_page() {
        $tabs = self::tabs();
        $urls = self::urls();

        // Filters
        $search_term  = isset( $_GET['search'] ) ? sanitize_text_field( $_GET['search'] ) : '';
        $stock_status = isset( $_GET['stock_status'] ) ? sanitize_text_field( $_GET['stock_status'] ) : '';
        $sites        = Woo_Multisite_Stock_Sync_Utils::sites();

        // Pagination
        $products_per_page = 10;
        $paged             = isset( $_GET['paged'] ) ? absint( $_GET['paged'] ) : 1;

        // Query products
        $query_params = array(
            'limit'        => $products_per_page,
            'page'         => $paged,
            'paginate'     => true,

            'stock_status' => $stock_status,
        );

        $query = Woo_Multisite_Stock_Sync_Utils::product_query( $query_params );
        if ( ! empty( $search_term ) ) {
            $data_store         = WC_Data_Store::load( 'product' );
            $search_product_ids = $data_store->search_products( $search_term );

            $query->set( 'include', $search_product_ids );
        }

        if ( ! empty( $query->get( 'include' ) ) || empty( $search_term ) ) {
            $results     = $query->get_products();
            $products    = $query->get( 'paginate' ) ? $results->products : $results;
            $total_count = $query->get( 'paginate' ) ? $results->total : count( $results );
            $total_pages = $query->get( 'paginate' ) ? $results->max_num_pages : 1;
        }

        // Include products with variations if needed
        $products_with_children = array();
        foreach ( $products as $product ) {
            $products_with_children[] = $product;

            // Include variations if the product is variable
            if ( $product->get_type() === 'variable' ) {
                $children = $product->get_children();
                foreach ( $children as $child_id ) {
                    $child_product = wc_get_product( $child_id );
                    if ( $child_product && $child_product->exists() ) {
                        $products_with_children[] = $child_product;
                    }
                }
            }
        }

        include __DIR__ . '/views/report.html.php';
    }


    public function tools_page() {
        $tabs = $this->tabs();
        $urls = $this->urls();

        include __DIR__ . '/views/tools.html.php';
    }


    // OLD LOGIC

    // Acción AJAX para desactivar la sincronización
    public function ajax_disable_sync() {
        check_ajax_referer( 'disable_sync_nonce', 'nonce' );

        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( array( 'message' => __( 'No tienes permisos para realizar esta acción.', 'woo-multisite-stock-sync' ) ) );
        }

        update_option( 'woo_multisite_stock_sync_enabled', false );
        wp_send_json_success( array( 'message' => __( 'Sincronización desactivada con éxito.', 'woo-multisite-stock-sync' ) ) );
    }
}
