<?php global $title; ?>

<div class="wrap" id="woo-multisite-stock-sync-tools">
    <h1 class="wp-heading-inline"><?php echo esc_html( $title ); ?></h1>
    <hr class="wp-header-end">

    <?php require 'tabs.html.php'; ?>

    <?php if ( Woo_Multisite_Stock_Sync_Utils::is_primary_site() ) { ?>

        <div style="padding: 1rem; margin: 2rem 0; border: 1px solid #2c3338; border-radius: 0.36rem;">
            <h2 style="margin-bottom: 2rem;"><?php esc_html_e( 'Herramientas', 'woo-multisite-stock-sync' ); ?></h2>

            <div class="tools">
                <div class="tool">
                    <div class="title"><?php _e( 'Sincronizar Todo', 'woo-multisite-stock-sync' ); ?></div>
                    <div class="desc"><?php _e( 'Actualiza los inventarios segundarios, sincronizando desde el inventario principal.', 'woo-multisite-stock-sync' ); ?></div>
                    <div class="action">
                        <a href="<?php echo $urls['push_all']; ?>" class="button button-primary"><?php _e( 'Sincronizar', 'woo-multisite-stock-sync' ); ?></a>
                    </div>
                </div>
                <div class="tool">
                    <div class="title"><?php _e( 'Actualizar inventario principal', 'woo-multisite-stock-sync' ); ?></div>
                    <div class="desc"><?php _e( 'Actualiza el inventario principal, sincronizando desde los inventarios segundarios.', 'woo-multisite-stock-sync' ); ?></div>
                    <div class="action">
                        <a href="<?php echo $urls['update']; ?>" class="button button-primary"><?php _e( 'Actualizar', 'woo-multisite-stock-sync' ); ?></a>
                    </div>
                </div>
                <div class="tool">
                    <div class="title"><?php _e( 'Desactivar sincronizacion', 'woo-multisite-stock-sync' ); ?></div>
                    <div class="desc"><?php _e( 'Desactiva la sincronizacion.', 'woo-multisite-stock-sync' ); ?></div>
                    <div class="action">
                        <button id="wmss-disable-sync" class="button button-primary"><?php esc_html_e( 'Desactivar sincronización', 'woo-multisite-stock-sync' ); ?></button>
                    </div>
                </div>

            </div>
        </div>

        <?php require 'debugger.html.php'; ?>

    <?php } else { ?>
        <p><?php printf( __( 'Please view report in <a href="%s" target="_blank">the Primary Inventory site.</a>', 'woo-multisite-stock-sync' ), Woo_Multisite_Stock_Sync_Utils::primary_report_url() ); ?></p>
    <?php } ?>
</div>
