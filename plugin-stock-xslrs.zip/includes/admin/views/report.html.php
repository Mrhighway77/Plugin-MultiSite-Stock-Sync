<?php global $title; ?>

<style>
    /* Styling for the search form */
    form {
        margin: 2rem 0;
        display: flex;
        gap: 1rem;
        flex-wrap: wrap;
        flex-direction: column-reverse;
        justify-content: start;
        align-items: start;

        div:has( :not( .form-field ) ) {
            display: flex;
            flex-wrap: wrap;
            gap: 1rem;
            flex-direction: row;
            justify-content: space-between;
            align-items: start;
            width: 100%;
        }

        .form-field {
            display: flex;
            flex-direction: column;
            flex: 1;
        }

        input[type="text"],
        select {
            padding: 0.5rem !important;
            font-size: 1rem;
            border: 1px solid #ccc;
            border-radius: 0.36rem !important;
            width: 100% !important;
            max-width: 100% !important;
        }

        label {
            font-weight: bold;
            margin-bottom: 0.5rem;
            font-size: 1rem;
        }

        button {
            padding: 0.3rem 0.8rem !important;
            font-size: 1rem;
            font-weight: bold;
            border-radius: 0.36rem !important;
            align-self: end;
            min-width: 200px;
        }
    }

    /* Styling for product table */
    .pagination {
        margin: 2rem 0;
        display: flex;
        justify-content: end;
    }

    .page-numbers {
        background-color: var(--wmss-color-bg-secondary, #0073aa);
        color: var(--wmss-color-primary, #FFF);
        padding: 0.5rem 1rem;
        border-radius: 0;
        text-decoration: none;
    }

    .page-numbers.current {
        background-color: var(--wmss-color-primary, #005177);
        color: var(--wmss-color-bg-primary, #FFF);
    }

    .page-numbers:hover {
        opacity: 0.86;
    }
</style>

<div class="wrap" id="woo-multisite-stock-sync-report">
    <h1 class="wp-heading-inline"><?php echo esc_html( $title ); ?></h1>
    <hr class="wp-header-end">

    <?php require 'tabs.html.php'; ?>

    <?php if ( Woo_Multisite_Stock_Sync_Utils::is_primary_site() ) { ?>

        <!-- Search and Filter Form -->
        <form method="get" action="">
            <input type="hidden" name="page" value="woo-multisite-stock-sync-report" />
            <div>
                <div class="form-field">
                    <label for="search"><?php esc_html_e( 'Buscar Productos:', 'woo-multisite-stock-sync' ); ?></label>
                    <input type="text" name="search" id="search" placeholder="<?php esc_html_e( 'Buscar por nombre, sku, etc.', 'woo-multisite-stock-sync' ); ?>" value="<?php echo esc_attr( $search_term ); ?>" />
                </div>
                <div class="form-field">
                    <label for="stock_status"><?php esc_html_e( 'Filtrar por Stock Status', 'woo-multisite-stock-sync' ); ?></label>
                    <select name="stock_status" id="stock_status">
                        <option value=""><?php esc_html_e( 'All', 'woo-multisite-stock-sync' ); ?></option>
                        <option value="instock" <?php selected( $stock_status, 'instock' ); ?>><?php esc_html_e( 'In Stock', 'woo-multisite-stock-sync' ); ?></option>
                        <option value="outofstock" <?php selected( $stock_status, 'outofstock' ); ?>><?php esc_html_e( 'Out of Stock', 'woo-multisite-stock-sync' ); ?></option>
                    </select>
                </div>
            </div>
            <button type="submit" class="button button-primary"><?php esc_html_e( 'Buscar', 'woo-multisite-stock-sync' ); ?></button>
        </form>

        <!-- Pagination -->
        <?php if ( isset( $total_pages ) && $total_pages >= 2 ) : ?>
            <div class="pagination">
                <?php
                $pagination_args = array(
                    'base'      => add_query_arg( 'paged', '%#%' ),
                    'format'    => '',
                    'total'     => $total_pages,
                    'current'   => $paged ?? 0,
                    'type'      => 'plain',
                    'prev_text' => __( '« Previous', 'woo-multisite-stock-sync' ),
                    'next_text' => __( 'Next »', 'woo-multisite-stock-sync' ),
                );
                echo paginate_links( $pagination_args );
                ?>
            </div>
        <?php endif; ?>

        <!-- Product Table -->
        <table class="wmss-table wp-list-table widefat fixed striped products">
            <thead>
                <tr>
                    <th><?php esc_html_e( 'Product', 'woo-multisite-stock-sync' ); ?></th>
                    <th><?php esc_html_e( 'SKU', 'woo-multisite-stock-sync' ); ?></th>
                    <th><?php esc_html_e( 'Stock', 'woo-multisite-stock-sync' ); ?></th>
                    <th><?php esc_html_e( 'Action', 'woo-multisite-stock-sync' ); ?></th>
                </tr>
            </thead>
            <tbody>
                <?php if ( ! empty( $products ) ) : ?>
                    <?php foreach ( $products as $product ) : ?>
                        <tr>
                            <td><?php echo esc_html( $product->get_name() ?: 'N/A' ); ?></td>
                            <td><?php echo esc_html( $product->get_sku() ?: 'N/A' ); ?></td>
                            <td><?php echo esc_html( $product->get_stock_quantity() ?: '0' ); ?></td>
                            <td>
                                <button type="button" class="button wmss-push-btn" data-product-id="<?php echo esc_attr( $product->get_id() ); ?>" title="<?php esc_html_e( 'Synchronize this product', 'woo-multisite-stock-sync' ); ?>">
                                    <?php esc_html_e( 'Sincronizar', 'woo-multisite-stock-sync' ); ?>
                                </button>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php else : ?>
                    <tr><td colspan="4"><?php esc_html_e( 'No products found for synchronization.', 'woo-multisite-stock-sync' ); ?></td></tr>
                <?php endif; ?>
            </tbody>
        </table>

        <?php require 'debugger.html.php'; ?>

    <?php } else { ?>
        <p><?php printf( __( 'Please view report in <a href="%s" target="_blank">the Primary Inventory site.</a>', 'woo-multisite-stock-sync' ), Woo_Multisite_Stock_Sync_Utils::primary_report_url() ); ?></p>
    <?php } ?>
</div>

<script>
    jQuery(document).ready(function($) {
        $('.wmss-push-btn').on('click', function() {
            var productId = $(this).data('product-id');
            var nonce = woo_multisite_stock_sync.nonces.push;

            Debugger.init();

            $.ajax({
                url: woo_multisite_stock_sync.ajax_urls.push,
                method: 'POST',
                data: {
                    action: 'wmss_push',
                    security: nonce,
                    product_id: productId,
                },
                beforeSend: function() {
                    Debugger.info('Starting synchronization for product ID ' + productId + '...');
                },
                success: function(response) {
                    if (response.success) {
                        var result = response.data;
                        Debugger.success('Synchronization complete: ' + result.success_count + '/' + result.total_sites + ' sites successful.');

                        result.success.forEach(function(success) {
                            Debugger.success('✓ ' + success.site + ': ' + success.message);
                        });

                        result.errors.forEach(function(error) {
                            Debugger.error('✗ ' + error.site + ': ' + error.message);
                        });
                    } else {
                        Debugger.error((response.data?.message || 'Invalid server response.'));
                    }
                },
                error: function(jqXHR, textStatus, errorThrown) {
                    Debugger.error('AJAX request failed: ' + textStatus);
                    console.error('AJAX Error:', jqXHR.responseText, textStatus, errorThrown);
                }
            });
        });
    });
</script>
