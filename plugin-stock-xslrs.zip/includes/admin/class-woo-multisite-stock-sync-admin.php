<?php

/**
 * Prevenir acceso directo al script.
 */
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Woo_Multisite_Stock_Sync_Admin {

    public function __construct() {
        add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_scripts' ), 15, 0 );

        // Comprobación de versión de WooCommerce.
        add_action( 'init', array( $this, 'version_check' ), 10, 0 );

        // Inicializar trabajos en segundo plano
        add_action( 'admin_init', array( $this, 'start_trackers' ), 10, 0 );

        // Agregar la página de configuración a WooCommerce.
        add_filter( 'woocommerce_get_settings_pages', array( $this, 'add_settings_page' ), 10, 1 );

        // AJAX
        add_action( 'wp_ajax_wmss_api_check', array( $this, 'check_api_access' ) );
        add_action( 'wp_ajax_wmss_push', array( $this, 'push' ) );
        add_action( 'wp_ajax_wmss_push_all', array( $this, 'push_all' ) );
        add_action( 'wp_ajax_wmss_update', array( $this, 'update' ) );
        add_action( 'wp_ajax_wmss_view_last_response', array( $this, 'view_last_response' ) );
    }

    public function start_trackers() {
        new Woo_Multisite_Stock_Sync_Tracker_Primary();
    }

    /**
     * Comprobar la versión de WooCommerce.
     *
     * @return void
     */
    public function version_check() {
        if ( ! Woo_Multisite_Stock_Sync_Utils::woocommerce_version_check() ) {
            WPFlashMessages::queue_flash_message(
                __( 'Multisite Stock Sync requires WooCommerce 6.0 or higher. Please update WooCommerce.', 'woo-multisite-stock-sync' ),
                'error'
            );
        }
    }

    /**
     * Verificar acceso a la API.
     * Este método está pendiente de implementación.
     *
     * @return void
     */
    public function check_api_access() {
        check_ajax_referer( 'wmss-api-check', 'security' );

        if ( ! current_user_can( 'manage_woocommerce' ) ) {
            http_response_code( 403 );
            die( 'Permission denied' );
        }

        $type   = isset( $_POST['type'] ) ? trim( $_POST['type'] ) : '';
        $url    = isset( $_POST['url'] ) ? trim( $_POST['url'] ) : '';
        $key    = isset( $_POST['key'] ) ? trim( $_POST['key'] ) : '';
        $secret = isset( $_POST['secret'] ) ? trim( $_POST['secret'] ) : '';

        $check = new Woo_Multisite_Stock_Sync_Api_Check( $url, $key, $secret );
        $check->check( $type );
    }

    /**
     * Agregar la página de configuración a WooCommerce.
     * Incluye el archivo de configuración y lo agrega al arreglo de páginas de configuración de WooCommerce.
     *
     * @param array $settings Las páginas de configuración actuales de WooCommerce.
     * @return array Las páginas de configuración actualizadas con la nueva página añadida.
     */
    public function add_settings_page( $settings ) {
        $settings[] = include_once WOO_MULTISITE_STOCK_SYNC_DIR_PATH . 'includes/admin/class-wc-settings-woo-multisite-stock-sync.php';

        return $settings;
    }

    public function enqueue_scripts() {
        wp_enqueue_style( 'woo-multisite-stock-sync-admin-css', WOO_MULTISITE_STOCK_SYNC_DIR_URL . 'public/admin/css/woo-multisite-stock-sync-admin.css', array( 'woocommerce_admin_styles', 'wp-jquery-ui-dialog' ), WOO_MULTISITE_STOCK_SYNC_VERSION );
        wp_enqueue_script( 'woo-multisite-stock-sync-admin-js', WOO_MULTISITE_STOCK_SYNC_DIR_URL . 'public/admin/js/woo-multisite-stock-sync-admin.js', array( 'jquery', 'wc-enhanced-select', 'jquery-tiptip', 'jquery-ui-dialog' ), WOO_MULTISITE_STOCK_SYNC_VERSION );

        $is_report_page   = isset( $_GET['page'] ) && $_GET['page'] === 'woo-multisite-stock-sync-report';
        $is_settings_page = isset( $_GET['page'], $_GET['tab'] ) && $_GET['page'] === 'wc-settings' && $_GET['tab'] === 'woo_multisite_stock_sync';
        $is_log_page      = isset( $_GET['page'], $_GET['action'] ) && $_GET['page'] === 'woo-multisite-stock-sync-report' && $_GET['action'] === 'log';

        if ( $is_log_page ) {
            wp_enqueue_style( 'wc-admin-layout' );
        }

        if ( $is_report_page || $is_settings_page ) {
            // Enqueue Vue.js only here to avoid clashing with other plugins using Vue.js
            wp_enqueue_script( 'vue-js', WOO_MULTISITE_STOCK_SYNC_DIR_URL . 'public/admin/js/vue.js', array( 'underscore' ), WOO_MULTISITE_STOCK_SYNC_VERSION );
        }

        $nonces = array(
            'push'          => wp_create_nonce( 'wmss-push' ),
            'update_qty'    => wp_create_nonce( 'wmss-update-qty' ),
            'push_all'      => wp_create_nonce( 'wmss-push-all' ),
            'update'        => wp_create_nonce( 'wmss-update' ),
            'api_check'     => wp_create_nonce( 'wmss-api-check' ),

            'disable_nonce' => wp_create_nonce( 'disable_sync_nonce' ),
        );

        wp_localize_script(
            'woo-multisite-stock-sync-admin-js',
            'woo_multisite_stock_sync',
            array(
                'ajax_urls' => self::ajax_urls( $nonces ),
                'nonces'    => $nonces,
            )
        );
    }

    /**
     * Get AJAX action URLs dynamically based on nonces.
     *
     * @param array $nonces Nonce array with keys representing actions.
     * @return array Generated URLs for each nonce.
     */
    private static function ajax_urls( $nonces ) {
        $urls   = array();
        $prefix = 'woo_multisite_stock_sync_';

        foreach ( $nonces as $action => $nonce ) {
            $urls[ $action ] = add_query_arg(
                array(
                    'action' => $prefix . $action,
                ),
                admin_url( 'admin-ajax.php' )
            );
        }

        return $urls;
    }

    public function push() {
        check_ajax_referer( 'wmss-push', 'security' );

        if ( ! current_user_can( 'manage_woocommerce' ) ) {
            http_response_code( 403 );
            die( 'Permission denied' );
        }

        $product = wc_get_product( $_POST['product_id'] );
        // $site    = Woo_Multisite_Stock_Sync_Utils::site_by_key( $_POST['site_key'] );
        // if ( ! $site || ! $product ) {
        // http_response_code( 422 );
        // die( 'Site or product not found' );
        // }

        if ( ! $product ) {
            $message = __( 'Producto no encontrado en sitio principal.', 'woo-multisite-stock-sync' );

            Woo_Multisite_Stock_Sync_Debugger::debug( $message );
            wp_send_json_error( array( 'message' => $message ) );
        }

        $sku = $product->get_sku();
        if ( empty( $sku ) ) {
            $message = __( 'No esta permitido sincronizar un producto sin sku.', 'woo-multisite-stock-sync' );

            Woo_Multisite_Stock_Sync_Debugger::warning( $message );
            wp_send_json_error( array( 'message' => $message ) );
        }

        $responses     = array();
        $errors        = array();
        $success_count = 0;

        $sites = Woo_Multisite_Stock_Sync_Utils::sites();
        foreach ( $sites as $site ) {
            $site_url   = $site['url'];
            $api_key    = $site['api_key'];
            $api_secret = $site['api_secret'];

            $client   = Woo_Multisite_Stock_Sync_Api_Client::create( $site_url, $api_key, $api_secret );
            $data     = $client->products::parse_product_to_json( $product );
            $response = $client->products->push_or_update( $data );

            if ( $response->has_error() ) {
                $woocommerce_error = function () use ( $response ) {
                    if ( isset( $response->body()['message'] ) ) {
                        return $response->body()['message'];
                    }

                    return __( 'Un error desconocido a ocurrido.', 'woo-multisite-stock-sync' );
                };

                $errors[] = array(
                    'site'    => $site['url'],
                    'message' => $response->error_msg() ?? $woocommerce_error(),
                );
                continue;
            }

            $responses[]    = array(
                'site'    => $site['url'],
                'message' => __( 'Producto sincronizado con exito.', 'woo-multisite-stock-sync' ),
            );
            $success_count += 1;
        }

        $result = array(
            'success_count' => $success_count,
            'total_sites'   => count( $sites ),
            'success'       => $responses,
            'errors'        => $errors,
        );

        wp_send_json_success( $result );
    }

    public function push_all() {
        check_ajax_referer( 'wmss-push-all', 'security' );

        if ( ! current_user_can( 'manage_woocommerce' ) ) {
            http_response_code( 403 );
            die( 'Permission denied' );
        }

        $page  = intval( $_POST['page'] );
        $limit = intval( $_POST['limit'] );

        $site = Woo_Multisite_Stock_Sync_Utils::site_by_key( $_POST['site_key'] );
        if ( ! $site ) {
            http_response_code( 422 );
            die( 'Site not found' );
        }

        $query = Woo_Multisite_Stock_Sync_Utils::product_query(
            array(
                'limit'    => $limit,
                'page'     => $page,
                'paginate' => true,
                'type'     => Woo_Multisite_Stock_Sync_Utils::product_types( array( 'variation' ) ),
            )
        );

        $results = $query->get_products();
        $client  = Woo_Multisite_Stock_Sync_Api_Client::create( $site['url'], $site['api_key'], $site['api_secret'] );

        $response = $client->products->update_batch( $results->products, $limit );
        if ( $response->has_error() ) {
            $woocommerce_error = function () use ( $response ) {
                if ( isset( $response->body()['message'] ) ) {
                    return $response->body()['message'];
                }

                return __( 'Un error desconocido a ocurrido.', 'woo-multisite-stock-sync' );
            };

            $error_data = wp_parse_args(
                array(
                    'code'    => $response->status_code(),
                    'headers' => null,
                    'body'    => $response->body(),
                ),
                $error_data
            );

            wp_send_json(
                array(
                    'status'     => 'error',
                    'errors'     => 'push error',
                    'error_data' => $error_data,
                ),
                200
            );
        }

        wp_send_json(
            array(
                'status'    => 'processed',
                'total'     => $results->total,
                'pages'     => $results->max_num_pages,
                'page'      => $page,
                'last_page' => $results->max_num_pages == $page,
                'count'     => count( $results->products ),
            ),
            200
        );
    }

    public function update() {
        check_ajax_referer( 'wmss-update', 'security' );

        if ( ! current_user_can( 'manage_woocommerce' ) ) {
            http_response_code( 403 );
            die( 'Permission denied' );
        }

        // If we are completing whole update (all sites has been processed),
        // just update timestamp
        if ( isset( $_POST['complete'] ) && $_POST['complete'] ) {
            update_option( 'woo_multisite_stock_sync_last_updated', time() );

            wp_send_json( null, 200 );
        }

        $page  = intval( $_POST['page'] );
        $limit = intval( $_POST['limit'] );

        $site = Woo_Multisite_Stock_Sync_Utils::site_by_key( $_POST['site_key'] );
        if ( ! $site ) {
            http_response_code( 422 );
            die( 'Site not found' );
        }

        $query = Woo_Multisite_Stock_Sync_Utils::product_query(
            array(
                'limit'    => $limit,
                'page'     => $page,
                'paginate' => true,
                'type'     => Woo_Multisite_Stock_Sync_Utils::product_types( array( 'variation' ) ),
            )
        );

        $results = $query->get_products();
        $skus    = array_filter(
            array_map(
                fn( $product ) => (string) $product->get_sku( 'edit' ),
                $results->products
            )
        );

        $client   = Woo_Multisite_Stock_Sync_Api_Client::create( $site['url'], $site['api_key'], $site['api_secret'] );
        $response = $client->get(
            'products',
            array(
                'sku'      => implode( ',', $skus ),
                'per_page' => 100,
                'context'  => 'edit',
            )
        );

        if ( $response->has_error() ) {
            wp_send_json(
                array(
                    'status'  => 'error',
                    'message' => 'Error while fetching products from the API ' . json_encode( $response ),
                ),
                422
            );
        }

        $update_response = $client->products->update_batch_local( $response->body(), $limit );
        if ( ! empty( $update_response->body()['errors'] ) ) {
            wp_send_json(
                array(
                    'status' => 'error',
                    'errors' => json_encode( $update_response->body()['errors'] ),
                ),
                200
            );
        } else {
            wp_send_json(
                array(
                    'status'    => 'processed',
                    'total'     => $results->total,
                    'pages'     => $results->max_num_pages,
                    'page'      => $page,
                    'last_page' => $results->max_num_pages == $page,
                    'count'     => count( $results->products ),
                ),
                200
            );
        }

        wp_send_json( array( 'status' => 'error' ), 422 );
    }

    public function view_last_response() {
        if ( ! current_user_can( 'manage_woocommerce' ) ) {
            http_response_code( 403 );
            die( 'Permission denied' );
        }

        $data    = get_option( 'wmss_last_response', array() );
        $code    = isset( $data['code'] ) ? $data['code'] : __( 'N/A', 'woo-multisite-stock-sync' );
        $body    = isset( $data['body'] ) ? $data['body'] : __( 'N/A', 'woo-multisite-stock-sync' );
        $headers = isset( $data['headers'] ) ? $data['headers'] : false;

        include 'views/last-response.html.php';
        die;
    }
}
