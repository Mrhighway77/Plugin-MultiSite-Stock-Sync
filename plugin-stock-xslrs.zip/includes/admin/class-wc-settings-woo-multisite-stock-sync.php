<?php

/**
 * Prevenir acceso directo al script.
 */
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class WC_Settings_Woo_Multisite_Stock_Sync extends WC_Settings_Page {

    public function __construct() {
        $this->id    = 'woo_multisite_stock_sync';
        $this->label = __( 'Multisite Stock Sync', 'woo-multisite-stock-sync' );

        add_filter( 'woocommerce_settings_tabs_array', array( $this, 'add_settings_page' ), 20 );

        add_action( 'woocommerce_settings_' . $this->id, array( $this, 'output' ) );
        add_action( 'woocommerce_settings_save_' . $this->id, array( $this, 'save' ) );
        add_action( 'woocommerce_sections_' . $this->id, array( $this, 'output_sections' ) );

        // Custom handler for outputting API credential table
        add_action( 'woocommerce_admin_field_wmss_credentials_table', array( $this, 'credentials_table' ), 10, 1 );
    }

    /**
     * Get sections.
     *
     * @return array
     */
    public function get_sections() {
        $sections = array(
            '' => __( 'Settings', 'woo-multisite-stock-sync' ),
        );

        return apply_filters( 'woocommerce_get_sections_' . $this->id, $sections );
    }

    /**
     * Get settings array.
     *
     * @return array
     */
    public function get_settings() {
        global $current_section;

        $settings = $this->get_general_settings();

        $settings = apply_filters( 'woocommerce_' . $this->id . '_settings', $settings );

        return apply_filters( 'woocommerce_get_settings_' . $this->id, $settings );
    }

    /**
     * Get general settings
     */
    private function get_general_settings() {
        $settings = array(
            array(
                'title' => __( 'Multisite Stock Sync', 'woo-multisite-stock-sync' ),
                'type'  => 'title',
                'id'    => $this->id . '_page_options',
            ),
        );

        $settings[ $this->id . '_enabled' ] = array(
            'title'   => __( 'Activo', 'woo-multisite-stock-sync' ),
            'type'    => 'checkbox',
            'id'      => $this->id . '_enabled',
            'default' => 'yes',
        );

        if ( Woo_Multisite_Stock_Sync_Utils::is_primary_site() ) {
            $title                     = __( 'Credenciales de API - Inventarios Segundarios', 'woo-multisite-stock-sync' );
            $supported_api_credentials = apply_filters( 'woo_multisite_stock_sync_supported_api_credentials', WOO_MULTISITE_STOCK_SYNC_MAX_SITES );
        } else {
            $title                     = __( 'Credenciales de API de inventario primario', 'woo-multisite-stock-sync' );
            $supported_api_credentials = WOO_MULTISITE_STOCK_SYNC_MAX_SITES;
        }

        // Add hidden fields for API credentials so they get processed in WC_Admin_Settings
        // Hidden fields dont contain real data, instead fields are outputted in wmss_credentials_table
        // which wouldn't get saved without this
        for ( $i = 0; $i < $supported_api_credentials; $i++ ) {
            $fields = array( 'woo_multisite_stock_sync_url', 'woo_multisite_stock_sync_api_key', 'woo_multisite_stock_sync_api_secret' );
            foreach ( $fields as $field ) {
                $settings[ $this->id . '_api_credentials_hidden_' . $field . '_' . $i ] = array(
                    'type' => 'hidden',
                    'id'   => Woo_Multisite_Stock_Sync_Utils::api_credentials_field_name( $field, $i ),
                );
            }
        }

        $settings[ $this->id . '_api_credentials' ] = array(
            'title'   => $title,
            'type'    => 'wmss_credentials_table',
            'id'      => $this->id . '_api_credentials',
            'default' => '',
            'sites'   => $supported_api_credentials,
        );

        $settings[ $this->id . '_page_options_end' ] = array(
            'type' => 'sectionend',
            'id'   => $this->id . '_page_options',
        );

        return $settings;
    }

    /**
     * Save settings
     */
    public function save() {
        parent::save();
    }

    /**
     * Generar la tabla de credenciales.
     *
     * @param array $value Configuración actual de la tabla de credenciales.
     */
    public function credentials_table( $value ) {
        $sites = array();
        for ( $i = 0; $i < $value['sites']; $i++ ) {
            $sites[ $i ] = array(
                'url'        => array(
                    'name'  => Woo_Multisite_Stock_Sync_Utils::api_credentials_field_name( 'woo_multisite_stock_sync_url', $i ),
                    'value' => Woo_Multisite_Stock_Sync_Utils::api_credentials_field_value( 'woo_multisite_stock_sync_url', $i ),
                ),
                'api_key'    => array(
                    'name'  => Woo_Multisite_Stock_Sync_Utils::api_credentials_field_name( 'woo_multisite_stock_sync_api_key', $i ),
                    'value' => Woo_Multisite_Stock_Sync_Utils::api_credentials_field_value( 'woo_multisite_stock_sync_api_key', $i ),
                ),
                'api_secret' => array(
                    'name'  => Woo_Multisite_Stock_Sync_Utils::api_credentials_field_name( 'woo_multisite_stock_sync_api_secret', $i ),
                    'value' => Woo_Multisite_Stock_Sync_Utils::api_credentials_field_value( 'woo_multisite_stock_sync_api_secret', $i ),
                ),
            );

            // Hide unused fields
            $sites[ $i ]['hide_row'] = true;
            foreach ( $sites[ $i ] as $attrs ) {
                if ( ! empty( $attrs['value'] ) ) {
                    $sites[ $i ]['hide_row'] = false;
                    break;
                }
            }
        }

        include 'views/credentials-table.html.php';
    }

    /**
     * Output settings
     */
    public function output() {
        parent::output();

        include 'views/api-check-modal.html.php';
    }
}

return new WC_Settings_Woo_Multisite_Stock_Sync();
