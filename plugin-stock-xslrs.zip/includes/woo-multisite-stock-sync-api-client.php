<?php

/**
 * Prevenir acceso directo al script.
 */
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Woo_Multisite_Stock_Sync_Api_Client {
    private $site_url;
    private $auth_header;

    /**
     * Instancia de la clase Woo_Multisite_Stock_Sync_Api_Client_Products.
     */
    public $products;

    /**
     * Constructor para inicializar el cliente de la API.
     *
     * @param string $site_url   La URL base del sitio de WooCommerce.
     * @param string $api_key    La clave de consumidor de la API de WooCommerce.
     * @param string $api_secret El secreto de consumidor de la API de WooCommerce.
     */
    public function __construct( $site_url, $api_key, $api_secret ) {
        $this->site_url    = trailingslashit( $site_url ) . 'wp-json/wc/v3/';
        $this->auth_header = array(
            'Authorization' => 'Basic ' . base64_encode( $api_key . ':' . $api_secret ),
            'Content-Type'  => 'application/json',
        );

        $this->products = new Woo_Multisite_Stock_Sync_Api_Client_Products( $this );
    }

    /**
     * Crear una nueva instancia del cliente API.
     *
     * @param string $site_url   La URL base del sitio de WooCommerce.
     * @param string $api_key    La clave de consumidor de la API de WooCommerce.
     * @param string $api_secret El secreto de consumidor de la API de WooCommerce.
     * @return Woo_Multisite_Stock_Sync_Api_Client La nueva instancia del cliente de API.
     */
    public static function create( $site_url, $api_key, $api_secret ) {
        return new self( $site_url, $api_key, $api_secret );
    }

    /**
     * Realizar una solicitud HTTP a la API de WooCommerce.
     *
     * @param string     $method   El método HTTP (GET, POST, PUT).
     * @param string     $endpoint El endpoint de la API.
     * @param array|null $data Los datos que se enviarán en el cuerpo de la solicitud (si corresponde).
     * @param array|null $args Los argumentos adicionales que se agregarán a la solicitud (query params, headers, etc.).
     * @return Woo_Multisite_Stock_Sync_Api_Response La respuesta de la API.
     */
    public function request( $method, $endpoint, $data = null, $args = null ) {
        $url = $this->site_url . $endpoint;

        if ( ! empty( $args ) ) {
            $url = add_query_arg( $args, $url );
        }

        $request_args = array(
            'method'  => $method,
            'headers' => $this->auth_header,
        );

        if ( $data ) {
            $request_args['body'] = wp_json_encode( $data );
        }

        $response = wp_remote_request( $url, $request_args );

        if ( is_wp_error( $response ) ) {
            $error_message = $response->get_error_message();
            if ( empty( $error_message ) ) {
                $error_message = __( 'Un error desconocido a ocurrido.', 'woo-multisite-stock-sync' );
            }

            return new Woo_Multisite_Stock_Sync_Api_Response( 0, null, $error_message );
        }

        $status_code = wp_remote_retrieve_response_code( $response );
        $body        = json_decode( wp_remote_retrieve_body( $response ), true );

        return new Woo_Multisite_Stock_Sync_Api_Response( $status_code, $body );
    }

    /**
     * Realizar una solicitud GET a la API.
     *
     * @param string $endpoint El endpoint de la API.
     * @param array  $args Argumentos adicionales (query params).
     * @return Woo_Multisite_Stock_Sync_Api_Response La respuesta de la API.
     */
    public function get( $endpoint, $args = array() ) {
        return $this->request( 'GET', $endpoint, null, $args );
    }

    /**
     * Realizar una solicitud POST a la API.
     *
     * @param string $endpoint El endpoint de la API.
     * @param array  $data     Los datos que se enviarán en el cuerpo de la solicitud.
     * @param array  $args     Argumentos adicionales.
     * @return Woo_Multisite_Stock_Sync_Api_Response La respuesta de la API.
     */
    public function post( $endpoint, $data, $args = array() ) {
        return $this->request( 'POST', $endpoint, $data, $args );
    }

    /**
     * Realizar una solicitud PUT a la API.
     *
     * @param string $endpoint El endpoint de la API.
     * @param array  $data     Los datos que se enviarán en el cuerpo de la solicitud.
     * @param array  $args     Argumentos adicionales.
     * @return Woo_Multisite_Stock_Sync_Api_Response La respuesta de la API.
     */
    public function put( $endpoint, $data, $args = array() ) {
        return $this->request( 'PUT', $endpoint, $data, $args );
    }
}

class Woo_Multisite_Stock_Sync_Api_Response {
    private $status_code;
    private $body;
    private $error_msg;

    /**
     * Constructor de la clase.
     *
     * @param int    $status_code El código de estado de la respuesta.
     * @param mixed  $body        El cuerpo de la respuesta.
     * @param string $error_msg   El mensaje de error, si lo hay.
     */
    public function __construct( $status_code, $body, $error_msg = null ) {
        $this->status_code = $status_code;
        $this->body        = $body;
        $this->error_msg   = $error_msg;
    }

    /**
     * Verifica si la respuesta contiene un error.
     *
     * @return bool Verdadero si hay un error, falso si no lo hay.
     */
    public function has_error() {
        return ! is_null( $this->error_msg ) || $this->status_code < 200 || $this->status_code >= 300;
    }

    /**
     * Obtiene el código de estado de la respuesta.
     *
     * @return int El código de estado HTTP.
     */
    public function status_code() {
        return $this->status_code;
    }

    /**
     * Obtiene el cuerpo de la respuesta.
     *
     * @return mixed El cuerpo de la respuesta (generalmente un array o un objeto).
     */
    public function body() {
        return $this->body;
    }

    /**
     * Obtener el mensaje de error de la respuesta si existe.
     *
     * @return string|null Mensaje de error o null si no hay error.
     */
    public function error_msg() {
        return $this->error_msg;
    }

    /**
     * Obtener el estado de la respuesta.
     *
     * @return string "success" o "error" dependiendo del estado de la respuesta.
     */
    public function status() {
        return $this->has_error() ? 'error' : 'success';
    }
}
