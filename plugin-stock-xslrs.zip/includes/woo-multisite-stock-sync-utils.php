<?php

/**
 * Prevenir acceso directo al script.
 */
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Woo_Multisite_Stock_Sync_Utils {

    /**
     * Obtener las claves de los sitios.
     *
     * @return array Claves de los sitios registrados.
     */
    public static function get_site_keys() {
        return array_map(
            function ( $site ) {
                return $site['key'];
            },
            self::sites()
        );
    }

    /**
     * Busca un sitio en la lista de sitios sincronizados mediante una clave proporcionada.
     *
     * Este método recorre todos los sitios disponibles y compara la clave de cada uno con la clave
     * proporcionada como parámetro. Si se encuentra un sitio con la clave correspondiente,
     * se devuelve dicho sitio. Si no se encuentra, se devuelve `false`.
     *
     * @param string $key La clave del sitio que se desea buscar.
     * @return array|false El sitio encontrado en caso de éxito, o `false` si no se encuentra el sitio.
     */
    public static function site_by_key( $key ) {
        $sites = self::sites();

        foreach ( $sites as $site ) {
            if ( $site['key'] === $key ) {
                return $site;
            }
        }

        return false;
    }

    /**
     * Obtener la lista de sitios.
     *
     * @return array Lista de sitios.
     */
    public static function sites() {
        $sites = array();

        for ( $i = 0; $i < apply_filters( 'woo_multisite_stock_sync_supported_api_credentials', WOO_MULTISITE_STOCK_SYNC_MAX_SITES ); $i++ ) {
            $url           = self::api_credentials_field_value( 'woo_multisite_stock_sync_url', $i );
            $formatted_url = self::format_site_url( $url );
            $api_key       = self::api_credentials_field_value( 'woo_multisite_stock_sync_api_key', $i );
            $api_secret    = self::api_credentials_field_value( 'woo_multisite_stock_sync_api_secret', $i );

            if ( ! empty( $url ) && ! empty( $api_key ) && ! empty( $api_secret ) ) {
                $sites[ $i ] = array(
                    'i'             => $i,
                    'key'           => sanitize_key( $url ),
                    'url'           => $url,
                    'formatted_url' => $formatted_url,
                    'letter'        => strtoupper( substr( $formatted_url, 0, 1 ) ),
                    'api_key'       => $api_key,
                    'api_secret'    => $api_secret,
                );
            }
        }

        return $sites;
    }

    /**
     * Formatea una URL del sitio para devolver un título limpio o un enlace HTML.
     *
     * Esta función elimina los prefijos "https://" y "http://" de la URL proporcionada,
     * devolviendo un título simplificado. Si se especifica el parámetro `$link`,
     * se genera un enlace HTML con el título como texto visible.
     *
     * @param string $url   La URL que se desea formatear.
     * @param bool   $link  Opcional. Si es `true`, devuelve un enlace HTML. Por defecto es `false`.
     *
     * @return string El título limpio o el enlace HTML generado.
     */
    public static function format_site_url( $url, $link = false ) {
        $title = str_replace( array( 'https://', 'http://' ), '', $url );

        if ( $link ) {
            return sprintf( '<a href="%s" target="_blank">%s</a>', $url, $title );
        }

        return $title;
    }

    /**
     * Verificar si WooCommerce 6.0 o superior está activo.
     *
     * @return bool True si WooCommerce 6.0 o superior está activo, False en caso contrario.
     */
    public static function woocommerce_version_check( $version = '6.0' ) {
        if ( class_exists( 'WooCommerce' ) ) {
            global $woocommerce;

            if ( version_compare( $woocommerce->version, $version, '>=' ) ) {
                return true;
            }
        }

        return false;
    }

    /**
     * Comprobar si el sitio es el principal.
     *
     * @return bool True si el sitio es principal, False en caso contrario.
     */
    public static function is_primary_site() {
        return self::get_role() === 'primary';
    }

    /**
     * Comprobar si el sitio es el segundario.
     *
     * @return bool True si el sitio es principal, False en caso contrario.
     */
    public static function is_secondary_site() {
        return self::get_role() === 'secondary';
    }

    /**
     * Obtener el rol del sitio.
     *
     * @return string Rol del sitio, 'primary' por defecto.
     */
    public static function get_role() {
        return get_option( 'woo_multisite_stock_sync_role', 'primary' );
    }

    /**
     * Get request source role (Primary / Inventory)
     */
    public static function request_role() {
        return isset( $GLOBALS['woo_multisite_stock_sync_request_role'] ) ? $GLOBALS['woo_multisite_stock_sync_request_role'] : false;
    }

    /**
     * Formatear el nombre del campo de las credenciales de la API.
     *
     * @param string $name Nombre base del campo.
     * @param int    $i Índice del campo (si es mayor que 0).
     *
     * @return string Nombre del campo formateado.
     */
    public static function api_credentials_field_name( $name, $i ) {
        if ( $i == 0 ) {
            return $name;
        }

        return sprintf( '%s_%d', $name, $i );
    }

    /**
     * Obtener el valor del campo de las credenciales de la API.
     *
     * @param string $name Nombre base del campo.
     * @param int    $i Índice del campo (si es mayor que 0).
     * @param string $default Valor por defecto si no se encuentra la opción.
     *
     * @return string Valor del campo, o el valor por defecto.
     */
    public static function api_credentials_field_value( $name, $i, $default = '' ) {
        if ( $i == 0 ) {
            $value_key = $name;
        } else {
            $value_key = sprintf( '%s_%d', $name, $i );
        }

        return get_option( $value_key, $default );
    }

    /**
     * URL para el reporte de Inventario Principal
     *
     * Esta función genera la URL al reporte principal de inventario
     * basado en los sitios configurados en la sincronización de stock.
     *
     * @param string $action Acción opcional que se incluirá como parámetro en la URL.
     * @return string La URL generada para el reporte principal de inventario, o una cadena vacía si no hay sitios configurados.
     */
    public static function primary_report_url( $action = '' ) {
        $sites = self::sites();

        if ( ! empty( $sites ) ) {
            $site = reset( $sites );

            return add_query_arg(
                array(
                    'page'   => 'woo-multisite-stock-sync-report',
                    'action' => $action,
                ),
                $site['url'] . '/wp-admin/admin.php'
            );
        }

        return '';
    }

    public static function status_filter_options() {
        return array(
            'all'      => __( 'All products', 'woo-multisite-stock-sync' ),
            'mismatch' => __( 'Stock mismatching', 'woo-multisite-stock-sync' ),
        );
    }

    /**
     * Get product query
     */
    public static function product_query( $params = array() ) {
        $query = new WC_Product_Query();
        $query->set( 'status', array( 'publish', 'private' ) );
        $query->set( 'type', self::product_types() );
        $query->set( 'order', 'ASC' );
        $query->set( 'orderby', 'ID' );

        foreach ( $params as $key => $value ) {
            $query->set( $key, $value );
        }

        return $query;
    }

    /**
     * Get product types
     */
    public static function product_types( $incl = array() ) {
        $types = apply_filters(
            'woo_multisite_stock_sync_product_types',
            array(
                'simple',
                'variable',
                'product-part',
                'variable-product-part',
                'bundle',
            )
        );

        return array_merge( $types, $incl );
    }

    /**
     * Verificar si debe proceder con la sincronización de inventario.
     *
     * @param WC_Product $product El objeto del producto de WooCommerce.
     * @return bool Si debe sincronizarse el inventario o no.
     */
    public static function should_sync( $product ) {
        // Si se está utilizando una versión de WooCommerce no compatible, abortar
        if ( ! self::woocommerce_version_check() ) {
            return false;
        }

        // Si la sincronización de inventario no está habilitada
        if ( get_option( 'woo_multisite_stock_sync_enabled', 'yes' ) !== 'yes' ) {
            return false;
        }

        // Si el cambio de inventario proviene del Inventario Principal, no crear un nuevo trabajo
        if ( self::request_role() === 'primary' ) {
            return false;
        }

        // Si es un Inventario Secundario y el cambio fue desencadenado por una solicitud de Stock Sync, no crear un nuevo trabajo
        if ( self::is_secondary_site() && self::is_self_request() ) {
            return false;
        }

        // Si el producto no está gestionando inventario
        if ( ! $product->managing_stock() ) {
            return false;
        }

        // Permitir que los plugins de terceros determinen si deben sincronizarse el stock
        if ( ! apply_filters( 'woo_multisite_stock_sync_should_sync', true, $product, 'stock_qty' ) ) {
            return false;
        }

        return true;
    }

    /**
     * Check if request is Woo Multisite Stock Sync request
     */
    public static function is_self_request() {
        return isset( $GLOBALS['woo_multisite_stock_sync_request'] ) && $GLOBALS['woo_multisite_stock_sync_request'];
    }

    /**
     * Get batch size
     */
    public static function get_batch_size( $operation = '' ) {
        $size = intval( get_option( 'woo_multisite_stock_sync_batch_size', 10 ) );

        return apply_filters( 'woo_multisite_stock_sync_batch_size', $size, $operation );
    }
}
