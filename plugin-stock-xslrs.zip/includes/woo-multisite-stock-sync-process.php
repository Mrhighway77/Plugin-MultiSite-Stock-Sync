<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Salir si se accede directamente.
}

class Woo_Multisite_Stock_Sync_Process extends WP_Async_Request {

    protected $action = 'wmss_background_process';

    /**
     * Encola una tarea de sincronización en segundo plano.
     *
     * @param callable $callback Función de callback a ejecutar cuando se procesa la tarea.
     * @param array    $data Datos adicionales que se pasan al callback.
     * @return mixed Resultado de la solicitud asincrónica o un error de tipo WP_Error.
     */
    public static function enqueue_task( $callback, $data = array() ) {
        // Creamos una nueva instancia de la tarea.
        $task = new self();

        // Almacenamos el callback y los datos adicionales en los datos de la tarea.
        $task->data = array(
            'callback' => $callback,
            'data'     => $data, // Aquí almacenamos los datos arbitrarios
        );

        // Encolamos la tarea para que se ejecute en segundo plano.
        return $task->dispatch();
    }

    /**
     * Método que maneja el procesamiento de la tarea.
     *
     * Este método ejecuta el callback pasado cuando se procesa la tarea, pasando los datos adicionales.
     */
    public function handle() {
        // Obtenemos el callback y los datos de la tarea.
        $callback = isset( $this->data['callback'] ) ? $this->data['callback'] : null;
        $data     = isset( $this->data['data'] ) ? $this->data['data'] : null;

        // Si el callback está definido y es callable, lo ejecutamos.
        if ( is_callable( $callback ) ) {
            // Ejecutamos el callback y le pasamos los datos como argumento.
            call_user_func( $callback, $data ); // Aquí pasamos los datos arbitrarios
        }
    }

    /**
     * Obtener el modelo de proceso (foreground o background).
     */
    private static function process_model() {
        return get_option( 'woo_stock_sync_process_model', 'background' );
    }

    /**
     * Verifica si la solicitud es válida.
     */
    private function verify() {
        $salt = isset( $_POST['salt'] ) ? $_POST['salt'] : '';
        $mac  = md5( implode( '|', array( $salt, NONCE_SALT ) ) );

        if ( $mac !== $_POST['mac'] ) {
            wp_die( -1, 403 ); // Bloquea la solicitud si la verificación falla.
        }

        return true;
    }

    /**
     * Este método asegura que el trabajo se maneja correctamente cuando se ejecuta en segundo plano.
     */
    public function maybe_handle() {
        // Evitamos bloquear otras solicitudes mientras procesamos.
        session_write_close();

        // Verificamos la solicitud.
        $this->verify();

        // Llamamos al manejador de la tarea.
        $this->handle();

        wp_die(); // Finaliza la solicitud.
    }

    /**
     * Método para obtener los argumentos de la consulta.
     *
     * @return array
     */
    public function get_query_args() {
        return array( 'action' => $this->action );
    }

    /**
     * Método para obtener la URL del servidor que procesa la solicitud.
     *
     * @return string
     */
    public function get_query_url() {
        return admin_url( 'admin-ajax.php' );
    }

    /**
     * Método para obtener los argumentos POST.
     *
     * @return array
     */
    public function get_post_args() {
        return array(
            'body'    => array(
                'salt' => uniqid(),
                'mac'  => md5( uniqid() ),
            ),
            'timeout' => 15,
        );
    }
}
