<?php

/**
 * Evitar acceso directo al script.
 */
if ( ! defined( 'ABSPATH' ) ) {
    exit; // Salir si se accede directamente.
}

class Woo_Multisite_Stock_Sync_Debugger {

    const LEVEL_OK    = 0;
    const LEVEL_WARN  = 1;
    const LEVEL_ERROR = 2;
    const LEVEL_DEBUG = 3;

    const LEVELS = array(
        'ok'      => self::LEVEL_OK,
        'warning' => self::LEVEL_WARN,
        'error'   => self::LEVEL_ERROR,
        'debug'   => self::LEVEL_DEBUG,
    );

    private static $log_file       = WOO_MULTISITE_STOCK_SYNC_DIR_PATH . 'logs/' . 'woo-multisite-stock-sync-debugger.log';
    private static $enabled_levels = array( self::LEVEL_ERROR, self::LEVEL_WARN, self::LEVEL_OK, self::LEVEL_DEBUG );
    private static $max_log_size   = 3 * 1024; // 3KB
    private static $max_log_lines  = 100; // 100 lines

    /**
     * Configurar el archivo de registro.
     *
     * @param string $log_file Ruta al archivo de registro.
     */
    public static function set_log_file( $log_file ) {
        self::$log_file = WOO_MULTISITE_STOCK_SYNC_DIR_PATH . 'logs/' . $log_file;

        if ( ! file_exists( self::$log_file ) ) {
            self::write_log( '' );
        }
    }

    /**
     * Función para escribir en el archivo de registro.
     * Esta función intentará escribir en el archivo, pero no hará nada si el archivo no es escribible.
     *
     * @param string $log_entry El contenido que se va a escribir en el archivo de registro.
     */
    public static function write_log( $log_entry ) {
        // Si el archivo no es escribible, simplemente no hacemos nada.
        if ( is_writable( self::$log_file ) ) {
            file_put_contents( self::$log_file, $log_entry, FILE_APPEND );
        }
    }

    /**
     * Configurar los niveles de registro habilitados.
     *
     * @param array $levels Array con los niveles habilitados (e.g., [self::LEVEL_ERROR, self::LEVEL_WARN]).
     */
    public static function set_levels( $levels ) {
        self::$enabled_levels = $levels;
    }

    /**
     * Registrar un mensaje con un nivel específico.
     *
     * @param int    $level   Nivel del mensaje (e.g., self::LEVEL_ERROR).
     * @param string $message Mensaje a registrar.
     */
    public static function log( $level, $message ) {
        if ( ! in_array( $level, self::$enabled_levels ) ) {
            return; // Ignorar niveles no habilitados
        }

        $level_name = array_search( $level, self::LEVELS, true );
        $timestamp  = date( 'Y-m-d H:i:s' );
        $log_entry  = "[$timestamp] [$level_name] $message" . PHP_EOL;

        // Verificar el tamaño del archivo antes de agregar un nuevo registro
        if ( file_exists( self::$log_file ) && ( filesize( self::$log_file ) >= self::$max_log_size || self::get_line_count() >= self::$max_log_lines ) ) {
            self::rotate_log();
        }

        self::write_log( $log_entry );
    }

    /**
     * Obtener el número de líneas del archivo de registro.
     *
     * @return int El número de líneas en el archivo de registro.
     */
    private static function get_line_count() {
        $lines = file( self::$log_file );
        return count( $lines );
    }

    /**
     * Rotar el archivo de registro (limpiar o truncar el archivo).
     */
    private static function rotate_log() {
        $lines = file( self::$log_file );
        if ( count( $lines ) > self::$max_log_lines ) {
            $lines = array_slice( $lines, -self::$max_log_lines );
        }

        self::write_log( implode( '', $lines ) );
    }

    /**
     * Registrar un mensaje de nivel OK.
     *
     * @param string $message Mensaje de nivel OK.
     */
    public static function ok( $message ) {
        self::log( self::LEVEL_OK, $message );
    }

    /**
     * Registrar un mensaje de advertencia (warning).
     *
     * @param string $message Mensaje de advertencia.
     */
    public static function warning( $message ) {
        self::log( self::LEVEL_WARN, $message );
    }

    /**
     * Registrar un mensaje de error.
     *
     * @param string $message Mensaje de error.
     */
    public static function error( $message ) {
        self::log( self::LEVEL_ERROR, $message );
    }

    /**
     * Registrar un mensaje de depuración (debug).
     *
     * @param string $message Mensaje de depuración.
     */
    public static function debug( $message ) {
        self::log( self::LEVEL_DEBUG, $message );
    }

    /**
     * Limpiar el contenido del archivo de registro.
     */
    public static function clear() {
        file_put_contents( self::$log_file, '' );
    }

    /**
     * Obtener los niveles de registro habilitados actualmente.
     *
     * @return array Los niveles habilitados.
     */
    public static function get_levels() {
        return self::$enabled_levels;
    }

    /**
     * Obtener la ruta actual del archivo de registro.
     *
     * @return string Ruta del archivo de registro.
     */
    public static function get_log_file() {
        return self::$log_file;
    }
}
