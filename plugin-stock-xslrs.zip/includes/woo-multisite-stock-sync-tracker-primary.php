<?php

/**
 * Evitar acceso directo al script.
 */
if ( ! defined( 'ABSPATH' ) ) {
    exit; // Salir si se accede directamente.
}

class Woo_Multisite_Stock_Sync_Tracker_Primary {

    public function __construct() {
        // add_action( 'woocommerce_product_set_stock', array( $this, 'on_product_set_stock' ) );
        add_action( 'woocommerce_product_set_stock', array( $this, 'sync_stock_with_sites' ) );
    }

    /**
     * Se activa cuando un producto es actualizado. Encola un trabajo en segundo plano.
     *
     * @param int $product_id ID del producto.
     */
    public function on_product_set_stock( $product_id ) {
        // FIXME: fix  task manager
        // Woo_Multisite_Stock_Sync_Process::enqueue_task( array( $this, 'sync_stock_with_sites' ), array( $product_id ) );
    }

    /**
     * Sincroniza los datos de stock del producto con los sitios externos.
     *
     * @param int $product_id ID del producto.
     */
    public function sync_stock_with_sites( $product_id ) {
        $product = wc_get_product( $product_id );

        if ( ! $product || empty( $product->get_sku() ) ) {
            return;
        }

        $sku  = $product->get_sku();
        $data = array(
            'sku'            => $sku,
            'stock_quantity' => $product->get_stock_quantity(),
            'manage_stock'   => $product->get_manage_stock(),
        );

        $sites         = Woo_Multisite_Stock_Sync_Utils::sites();
        $responses     = array();
        $errors        = array();
        $success_count = 0;

        foreach ( $sites as $site ) {
            $client   = Woo_Multisite_Stock_Sync_Api_Client::create( $site['url'], $site['api_key'], $site['api_secret'] );
            $response = $client->products->update( $data );

            if ( $response->has_error() ) {
                $errors[] = array(
                    'site'    => $site['url'],
                    'message' => $response->error_msg(),
                );

                continue;
            }

            if ( $response->status_code() !== 200 || empty( $response->body() ) ) {
                continue;
            }

            $responses[] = array(
                'site'    => $site['url'],
                'message' => 'Producto sincronizado correctamente',
            );
            ++$success_count;
        }

        $result = array(
            'success_count' => $success_count,
            'total_sites'   => count( $sites ),
            'success'       => $responses,
            'errors'        => $errors,
        );

        $message = sprintf(
            '%d de %d sitios sincronizados con éxito.',
            $result['success_count'],
            $result['total_sites']
        );

        if ( ! empty( $result['errors'] ) ) {
            $message .= '<br>[WOO_MULTISITE_STOCK_SYNC] <strong>Errores:</strong> ' . implode( ', ', $result['errors'] );
            Woo_Multisite_Stock_Sync_Debugger::error( $message );
        }

        WPFlashMessages::queue_flash_message( $message, 'notice-info' );
    }

    /**
     * Verificar si la cantidad de stock del producto ha cambiado.
     *
     * TODO: Implementar la lógica para verificar si la cantidad de stock ha cambiado
     * Esto podría implicar comparar el stock actual con un valor almacenado en la base de datos o mediante hooks.
     *
     * @param int $product_id ID del producto.
     * @return bool
     */
    private function has_stock_changed( $product_id ) {
        return true;
    }
}
