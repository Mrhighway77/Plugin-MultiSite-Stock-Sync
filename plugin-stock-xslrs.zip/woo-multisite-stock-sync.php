<?php

/**
 * WooCommerce Multisite Stock Sync
 *
 * @package             PluginPackage
 * @author              Marco, Emanuel
 * @license             GPL-2.0-or-later
 *
 * @wordpress-plugin
 * Plugin Name:         WooCommerce MultiSite Stock Sync
 * Description:         Coordina el stock de productos entre páginas web alojadas en el mismo hosting.
 * Version:             1.0.0
 * Requires at least:   5.6 and (WooCommerce >= 6.0.0)
 * Author:              Marco, Emanuel
 * License:             GPL v2 or later
 * License URI:         http://www.gnu.org/licenses/gpl-2.0.txt
 * Requires Plugins:    WooCommerce MultiSite Stock Sync, WooCommerce
 */

/**
 * Prevent Direct Acess
 */
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Plugin file
 */
if ( ! defined( 'WOO_MULTISITE_STOCK_SYNC_FILE' ) ) {
    define( 'WOO_MULTISITE_STOCK_SYNC_FILE', __FILE__ );
}

class Woo_Multisite_Stock_Sync {

    public function __construct() {}

    public static function init() {
        load_plugin_textdomain( 'woo-multisite-stock-sync', false, plugin_dir_path( __FILE__ ) . '/languages' );

        if ( ! class_exists( 'WooCommerce' ) ) {
            add_action(
                'admin_notices',
                function () {
                    echo '<div class="error"><p>' . __( 'El plugin WooCommerce debe estar instalado y activado para usar el plugin "Multisite Stock Sync".', 'woo-multisite-stock-sync' ) . '</p></div>';
                }
            );

            return;
        }

        self::define_constants();
        self::includes();
    }

    public static function define_constants() {
        if ( ! defined( 'WOO_MULTISITE_STOCK_SYNC_MAX_SITES' ) ) {
            define( 'WOO_MULTISITE_STOCK_SYNC_MAX_SITES', 50 );
        }

        if ( ! defined( 'WOO_MULTISITE_STOCK_SYNC_DIR_URL' ) ) {
            define( 'WOO_MULTISITE_STOCK_SYNC_DIR_URL', plugin_dir_url( __FILE__ ) );
        }

        if ( ! defined( 'WOO_MULTISITE_STOCK_SYNC_VERSION' ) ) {
            define( 'WOO_MULTISITE_STOCK_SYNC_VERSION', '1.0.0' );
        }

        if ( ! defined( 'WOO_MULTISITE_STOCK_SYNC_BASENAME' ) ) {
            define( 'WOO_MULTISITE_STOCK_SYNC_BASENAME', plugin_basename( __FILE__ ) );
        }

        if ( ! defined( 'WOO_MULTISITE_STOCK_SYNC_DIR_PATH' ) ) {
            define( 'WOO_MULTISITE_STOCK_SYNC_DIR_PATH', plugin_dir_path( __FILE__ ) );
        }
    }

    public static function includes() {
        self::load_class( 'includes/woo-multisite-stock-sync-utils.php' );
        self::load_class( 'includes/woo-multisite-stock-sync-debugger.php' );
        self::load_class( 'includes/woo-multisite-stock-sync-api-check.php' );
        self::load_class( 'includes/woo-multisite-stock-sync-api-client-products.php' );
        self::load_class( 'includes/woo-multisite-stock-sync-api-client.php' );
        self::load_class( 'includes/woo-multisite-stock-sync-process.php' );
        self::load_class( 'includes/woo-multisite-stock-sync-tracker-primary.php' );

        if ( is_admin() ) {
            self::admin_includes();
        }

        self::load_class( 'includes/wp-flash-messages.php', false );
    }

    private static function admin_includes() {
        self::load_class( 'includes/admin/class-woo-multisite-stock-sync-admin.php', 'Woo_Multisite_Stock_Sync_Admin' );
        self::load_class( 'includes/admin/class-woo-multisite-stock-sync-ui.php', 'Woo_Multisite_Stock_Sync_Ui' );
    }

    /**
     * Carga un archivo de clase y, opcionalmente, instancia la clase.
     *
     * @param string      $filepath La ruta relativa del archivo de clase a incluir.
     *                              Debe ser relativa a la constante `WOO_MULTISITE_STOCK_SYNC_DIR_PATH`.
     * @param string|bool $class_name (Opcional) El nombre de la clase a instanciar.
     *                                Si se establece como `FALSE`, la clase no se instancia.
     *
     * @return object|bool Devuelve una instancia de la clase si se proporciona $class_name,
     *                     o `TRUE` si el archivo se carga sin instanciación.
     */
    private static function load_class( $filepath, $class_name = false ) {
        require_once WOO_MULTISITE_STOCK_SYNC_DIR_PATH . $filepath;

        if ( $class_name ) {
            return new $class_name();
        }

        return true;
    }
}

add_action( 'plugins_loaded', array( 'Woo_Multisite_Stock_Sync', 'init' ) );
